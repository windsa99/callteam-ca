CALLTEAM B2B COLD CALLING STARTER KIT

Start in Campaign Brief, then complete Script Worksheet. Log each call attempt in Call Tracker. Worked Example is fictional and illustrates how to complete the documents.

The workbook has 200 prepared log rows. Summary formulas count outcome entries, not unique prospects. Extend the formula ranges when adding rows. Use the same Contact ID for repeat calls. Honour contact preferences.

XLSX: editable workbook, dropdowns and summary counts.
PDF: three-page quick-start guide and fictional example.
CSV: blank call log without formulas or dropdowns.

The 100 full scripts are online: https://www.callteam.ca/resources/cold-call-scripts/
Campaign Preview: https://www.callteam.ca/b2b-outbound-campaign-planner/
Script Checker: https://www.callteam.ca/cold-call-script-checker/
Book a strategy call: https://calendly.com/hello-callteam/new-meeting

Free to use and adapt for your business. Version: 2026-10-25.
